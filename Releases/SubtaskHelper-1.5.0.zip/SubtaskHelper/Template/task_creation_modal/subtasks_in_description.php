<br>
<i style="opacity: 0.5; display: inline-block; margin-top: 0.5em;" title="<?= t("E.g.:\nDescription\n---\nSubtask:0:30\nSubtask 2:0:45") ?>">
    <?= t('Description text can contain "---" and directly subtasks underneath it with just a single newline.') ?>
</i>