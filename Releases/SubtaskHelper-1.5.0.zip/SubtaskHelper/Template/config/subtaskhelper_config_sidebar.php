<li <?= $this->app->checkMenuSelection('SubtaskHelperController', 'showConfig') ?>>
    <a href="/subtaskhelper/config"><?= t('SubtaskHelper configuration') ?></a>
</li>
